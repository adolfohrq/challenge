(function ($) {
    "use strict";

    // Theme color control js
    $(document).ready(function () {
        const isDarkMode = localStorage.getItem('darkMode') === 'true';
        $('body').toggleClass('dark-theme', isDarkMode);

        $('#page-content').fadeIn(0);

        $('.theme-control-btn').on("click", function () {
            $('body').toggleClass('dark-theme');

            const isDark = $('body').hasClass('dark-theme');
            localStorage.setItem('darkMode', isDark);
        });

        // Mobile menu control js
        $(".mobile-menu-control-bar").on("click", function () {
            $(".mobile-menu-overlay").addClass("show");
            $(".navbar-main").addClass("show");
        });
        $(".mobile-menu-overlay").on("click", function () {
            $(".mobile-menu-overlay").removeClass("show");
            $(".navbar-main").removeClass("show");
        });

        // Email copy button js
        new ClipboardJS('.btn-copy');

        // Email copy button tooltip js
        $(".btn-copy").on("click", function () {
            $(this).addClass("active");

            setTimeout(() => {
                $(this).removeClass("active");
            }, 1000);
        });

        // Magnific popup js ajustado para galeria por projeto
        $(".project-item").each(function() {
            $(this).magnificPopup({
                delegate: ".gallery-popup", // Seletor para cada item da galeria
                type: "image",
                gallery: {
                    enabled: true, // Habilitar modo de galeria
                }
            });
        });

        // Client feedback slider js
        $(".client-feedback-slider").slick({
            slidesToShow: 2,
            slidesToScroll: 1,
            autoplay: false,
            dots: false,
            infinite: true,
            arrows: true,
            speed: 500,
            prevArrow: '<i class="fas left icon fa-arrow-left"></i>',
            nextArrow: '<i class="fas right icon fa-arrow-right"></i>',
            responsive: [{
                breakpoint: 768,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                }
            },]
        });

        // Article publications slider js
        $(".article-publications-slider").slick({
            slidesToShow: 2,
            slidesToScroll: 1,
            autoplay: false,
            dots: false,
            infinite: true,
            arrows: true,
            speed: 500,
            prevArrow: '<i class="fas left icon fa-arrow-left"></i>',
            nextArrow: '<i class="fas right icon fa-arrow-right"></i>',
            responsive: [{
                breakpoint: 768,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                }
            },]
        });

        // Função para lidar com os filtros de categorias (tabs)
        const tabButtons = document.querySelectorAll('.tab-btn');
        const projects = document.querySelectorAll('.project-item');

        tabButtons.forEach(button => {
            button.addEventListener('click', () => {
                const category = button.getAttribute('data-category');

                // Remover classe 'active' de todos os botões
                tabButtons.forEach(btn => btn.classList.remove('active'));
                button.classList.add('active');

                // Mostrar/ocultar projetos com base na categoria
                projects.forEach(project => {
                    if (category === 'all' || project.getAttribute('data-category') === category) {
                        project.style.display = 'block';  // Mostra o projeto
                    } else {
                        project.style.display = 'none';   // Esconde o projeto
                    }
                });
            });
        });

    });

})(jQuery);
