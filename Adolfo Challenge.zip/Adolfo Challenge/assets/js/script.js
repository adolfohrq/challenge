(function ($) {
    "use strict";

    $(document).ready(function () {
        $('#page-content').fadeIn(0);

        /*=============================
        Mobile Menu - JS
        ===============================*/

        // Abre o menu móvel e o overlay
        $(".mobile-menu-control-bar").on("click", function () {
            $(".mobile-menu-overlay").addClass("show");
            $(".navbar-main").addClass("show");
        });

        // Fecha o menu e o overlay ao clicar no overlay
        $(".mobile-menu-overlay").on("click", function () {
            $(".mobile-menu-overlay").removeClass("show");
            $(".navbar-main").removeClass("show");
        });

        // Fecha o menu e o overlay ao clicar em qualquer item do menu
        $(".navbar-main .nav-link").on("click", function () {
            $(".mobile-menu-overlay").removeClass("show");
            $(".navbar-main").removeClass("show");
        });

        // Scroll suave com ajuste de deslocamento
        $('.nav-link').on('click', function (e) {
            e.preventDefault();
            var target = $(this).attr('href'); // Obtém o destino do link
            var offset = $(target).offset().top - 100; // Ajusta o valor de deslocamento aqui (100px é o exemplo)

            $('html, body').animate({
                scrollTop: offset
            }, 600); // A duração da animação, 600ms é uma rolagem suave
        });



        /*=============================
        E-mail Copy - JS
        ===============================*/

        new ClipboardJS('.btn-copy');

        $(".btn-copy").on("click", function () {
            $(this).addClass("active");

            setTimeout(() => {
                $(this).removeClass("active");
            }, 1000);
        });

        /*=============================
        Project PopUp - JS
        ===============================*/

        $(".projects-item").each(function() {
            $(this).magnificPopup({
                delegate: ".gallery-popup",
                type: "image",
                gallery: {
                    enabled: true, 
                }
            });
        });



        /*=============================
        Project Tabs - JS
        ===============================*/

        const tabButtons = document.querySelectorAll('.tab-btn');
        const projects = document.querySelectorAll('.projects-item'); // Aqui a variável "projects" é declarada

        tabButtons.forEach(button => {
            button.addEventListener('click', () => {
                const category = button.getAttribute('data-category');

                tabButtons.forEach(btn => btn.classList.remove('active'));
                button.classList.add('active');

                projects.forEach(project => {
                    if (category === 'all' || project.getAttribute('data-category') === category) {
                        project.style.display = 'block';
                    } else {
                        project.style.display = 'none';
                    }
                });
            });
        });

        /*=============================
        Filtragem de Projetos - JS
        ===============================*/

        function filterProjects(category) {
            $('.projects-item').hide(); // Esconde todos os projetos
            if (category === 'all') {
                $('.projects-item').fadeIn(); // Mostra todos os projetos
            } else {
                $('.projects-item[data-category="' + category + '"]').fadeIn(); // Mostra apenas os projetos da categoria
            }
        }

        $(".projects-tabs .tab-btn").on("click", function () {
            var category = $(this).data('category');
            $(".projects-tabs .tab-btn").removeClass('active');
            $(this).addClass('active');
            filterProjects(category);
        });

        $(".projects-tabs-mobile .filter-text").on("click", function () {
            var category = $(this).data('category');
            $(".projects-tabs-mobile .filter-text").removeClass('active');
            $(this).addClass('active');
            filterProjects(category);
        });

        /*=============================
        Carousel Projetos - JS
        ===============================*/

        $('.projects-grid').slick({
            slidesToShow: 4, // Mostra 4 projetos de cada vez no desktop
            slidesToScroll: 4, // Rola 4 projetos de uma vez no desktop
            rows: 2, // Mostra 2 linhas de projetos no desktop
            infinite: false, // Desativa o loop infinito
            arrows: false, // Remove as setas de navegação
            dots: true, // Mostra os dots de navegação
            responsive: [
                {
                    breakpoint: 768, // Quando a largura da tela for menor que 768px (mobile)
                    settings: {
                        slidesToShow: 1, // Mostra 1 projeto por vez no mobile
                        slidesToScroll: 1, // Rola 1 projeto por vez no mobile
                        rows: 2, // Mostra 1 linha de projetos no mobile
                        dots: true, // Mantém os dots no mobile
                        arrows: false // Remove as setas no mobile
                    }
                }
            ]
        });
    });
})(jQuery);
